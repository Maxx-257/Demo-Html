"""Practical 8: Face detection using OpenCV Haar cascades."""
from pathlib import Path
import os
import cv2
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
img = cv2.imread(str(BASE / "assets" / "astronaut.jpg"))
if img is None:
    print("Input image not found.")
    raise SystemExit(0)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
if cascade.empty():
    print("Haar cascade could not be loaded.")
    raise SystemExit(0)
faces = cascade.detectMultiScale(gray, 1.1, 5, minSize=(40,40))
out = img.copy()
for (x,y,w,h) in faces: cv2.rectangle(out,(x,y),(x+w,y+h),(0,255,0),3)
cv2.imwrite(str(BASE / "output_face_detection.jpg"), out)
print("Faces detected:", len(faces))
plt.imshow(cv2.cvtColor(out,cv2.COLOR_BGR2RGB)); plt.axis("off"); plt.title("Haar Face Detection"); plt.tight_layout()
plt.savefig(BASE / "output_face_detection_plot.png", dpi=120)
if os.environ.get("DIP_TEST_MODE") != "1": plt.show()
plt.close()
print("SUCCESS: Haar face detection completed.")
