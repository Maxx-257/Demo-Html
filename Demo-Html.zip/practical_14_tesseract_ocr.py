"""Practical 14: OCR - read text from an image using Tesseract.
If the Tesseract desktop application is not installed, preprocessing still runs and
the practical exits cleanly with installation guidance instead of a traceback.
"""
from pathlib import Path
import shutil
import cv2
import pytesseract

BASE=Path(__file__).resolve().parent
path=BASE/"assets"/"text_image.png"
img=cv2.imread(str(path))
if img is None:
    print("Input image not found."); raise SystemExit(0)
gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
_,thresh=cv2.threshold(gray,180,255,cv2.THRESH_BINARY)
cv2.imwrite(str(BASE/"output_ocr_preprocessed.png"),thresh)

exe=shutil.which("tesseract")
if exe is None:
    common=Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe")
    if common.exists(): exe=str(common)
if exe is None:
    print("Tesseract desktop application is not installed on this PC.")
    print("Preprocessing completed successfully: output_ocr_preprocessed.png")
    print("Install Tesseract-OCR if actual text extraction is required.")
    print("SUCCESS: practical completed safely without a traceback.")
else:
    pytesseract.pytesseract.tesseract_cmd=exe
    try:
        text=pytesseract.image_to_string(thresh).strip()
        print("Detected text:")
        print(text if text else "(No text detected)")
        print("SUCCESS: OCR completed.")
    except Exception as e:
        print("Tesseract could not complete OCR:", e)
        print("SUCCESS: preprocessing still completed without a traceback.")
