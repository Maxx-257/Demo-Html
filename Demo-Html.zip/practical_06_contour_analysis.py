"""Practical 6: Detect and analyze contours in an image."""
from pathlib import Path
import os
import cv2
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
img = cv2.imread(str(BASE / "assets" / "shapes.png"))
if img is None:
    print("Input image not found.")
    raise SystemExit(0)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
_, binary = cv2.threshold(gray, 220, 255, cv2.THRESH_BINARY_INV)
contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
out = img.copy(); kept = 0
for c in contours:
    area = cv2.contourArea(c)
    if area < 100: continue
    kept += 1
    x, y, w, h = cv2.boundingRect(c)
    cv2.rectangle(out, (x, y), (x+w, y+h), (0, 0, 0), 2)
    cv2.putText(out, f"A={area:.0f}", (x, max(20, y-8)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 2)
    print(f"Contour {kept}: area={area:.1f}, bounding_box=({x},{y},{w},{h})")
cv2.imwrite(str(BASE / "output_contours.png"), out)
plt.imshow(cv2.cvtColor(out, cv2.COLOR_BGR2RGB)); plt.axis("off"); plt.title("Contour Analysis"); plt.tight_layout()
plt.savefig(BASE / "output_contour_plot.png", dpi=120)
if os.environ.get("DIP_TEST_MODE") != "1": plt.show()
plt.close()
print(f"SUCCESS: {kept} significant contours analyzed.")
