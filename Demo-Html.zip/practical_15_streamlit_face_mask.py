"""Practical 15: Deploy a real-time face-mask detector using Streamlit.
Recommended command: streamlit run practical_15_streamlit_face_mask.py
If Streamlit/camera mode is unavailable, running this file with Python performs a
safe offline face-detection demo and saves an output image.
"""
from pathlib import Path
import cv2
import numpy as np

BASE=Path(__file__).resolve().parent

def classify_mask_heuristic(face_bgr):
    # Classroom-safe lightweight heuristic: estimate how much of the lower face is
    # highly saturated. It is intentionally simple; deployment flow is the focus.
    hsv=cv2.cvtColor(face_bgr,cv2.COLOR_BGR2HSV)
    lower=hsv[hsv.shape[0]//2:]
    sat=float(np.mean(lower[:,:,1]))
    return ("Mask", min(0.99,0.55+sat/510.0)) if sat>75 else ("No Mask", min(0.99,0.65+(75-sat)/250.0))

def process_frame(frame):
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    cascade=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml")
    faces=cascade.detectMultiScale(gray,1.1,5,minSize=(50,50)) if not cascade.empty() else []
    for x,y,w,h in faces:
        crop=frame[y:y+h,x:x+w]; label,score=classify_mask_heuristic(crop)
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
        cv2.putText(frame,f"{label} {score:.2f}",(x,max(25,y-8)),cv2.FONT_HERSHEY_SIMPLEX,.65,(0,255,0),2)
    return frame, len(faces)

def cli_demo():
    img=cv2.imread(str(BASE/"assets"/"astronaut.jpg"))
    if img is None:
        print("Sample image missing."); return
    out,n=process_frame(img)
    cv2.imwrite(str(BASE/"output_face_mask_demo.jpg"),out)
    print("Faces detected:",n)
    print("SUCCESS: offline face-mask deployment demo saved as output_face_mask_demo.jpg")
    print("For the Streamlit interface run: streamlit run practical_15_streamlit_face_mask.py")

# Detect whether the script is actually running inside Streamlit.
try:
    import streamlit as st
    try:
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        in_streamlit = get_script_run_ctx(suppress_warning=True) is not None
    except Exception:
        in_streamlit = False
except Exception:
    st=None; in_streamlit=False

if not in_streamlit:
    cli_demo()
else:
    st.title("Real-Time Face Mask Detector - Practical 15")
    st.caption("Haar face detection + lightweight lower-face mask heuristic. Works without TensorFlow.")
    photo=st.camera_input("Take a photo")
    if photo is not None:
        data=np.frombuffer(photo.getvalue(),dtype=np.uint8)
        frame=cv2.imdecode(data,cv2.IMREAD_COLOR)
        out,n=process_frame(frame)
        if n==0: st.warning("No face detected. Try better lighting and face the camera directly.")
        st.image(cv2.cvtColor(out,cv2.COLOR_BGR2RGB),caption=f"Detected faces: {n}")
