"""Practical 13: Capture and process webcam video in real time using OpenCV.
Press Q to quit. If a webcam is unavailable, a bundled sample image is processed
instead so the practical completes without an exception.
"""
from pathlib import Path
import os
import cv2

BASE=Path(__file__).resolve().parent

def sample_fallback(reason):
    print("Webcam mode unavailable:", reason)
    img=cv2.imread(str(BASE/"assets"/"astronaut.jpg"))
    if img is None:
        print("Sample image missing."); return
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY); edges=cv2.Canny(gray,80,160)
    cv2.imwrite(str(BASE/"output_webcam_fallback_gray.jpg"),gray)
    cv2.imwrite(str(BASE/"output_webcam_fallback_edges.jpg"),edges)
    print("SUCCESS: sample-frame processing fallback completed.")

if os.environ.get("DIP_TEST_MODE") == "1":
    sample_fallback("test mode")
else:
    cap=cv2.VideoCapture(0)
    if not cap.isOpened():
        sample_fallback("camera not available or permission denied")
    else:
        print("Webcam opened. Press Q to quit.")
        try:
            while True:
                ok,frame=cap.read()
                if not ok: break
                gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY); edges=cv2.Canny(gray,80,160)
                cv2.imshow("Original - press Q to quit",frame); cv2.imshow("Canny Edges",edges)
                if cv2.waitKey(1)&0xFF==ord("q"): break
        finally:
            cap.release(); cv2.destroyAllWindows()
        print("SUCCESS: webcam processing completed.")
