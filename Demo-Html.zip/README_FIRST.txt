DIGITAL IMAGE PROCESSING - ALL 15 PRACTICALS
Course: Digital Image Processing (26UBCA507)
WINDOWS / VS CODE - QUICK EXAM SETUP

============================================================
FASTEST FIRST-TIME SETUP
============================================================
1. Extract this ZIP completely.
2. Open the ENTIRE extracted folder in VS Code.
3. Open Terminal -> New Terminal.
4. Type:

      SETUP_ONCE.bat

5. Wait until you see:

      SETUP COMPLETE

6. Close that terminal and open Terminal -> New Terminal once.
   VS Code is already configured to use:

      .venv\Scripts\python.exe

   You do NOT need to copy or select an interpreter manually.

7. Optional but recommended before the practical exam:

      TEST_ALL.bat

   It tests all 15 files in safe mode without requiring a webcam,
   pop-up windows, internet downloads, TensorFlow or YOLO weights.

============================================================
HOW TO RUN A PRACTICAL
============================================================
Example:

      python practical_04_sobel_canny.py

You can also use VS Code -> Run Python File in Terminal.
Do NOT use the Code Runner extension's "Run Code" button because it may
ignore the virtual environment.

Practical 15 Streamlit interface:

      streamlit run practical_15_streamlit_face_mask.py

============================================================
IMPORTANT - DESIGNED TO AVOID EXAM-TIME ERRORS
============================================================
- Sample images are already included in the assets folder.
- The setup installs all STABLE packages required by Practicals 1-9,
  13-15 and by the safe fallback modes.
- Practicals 10, 11 and 12 contain the full YOLOv5 / TensorFlow-Keras /
  ResNet code, but these technologies are large and may need downloads.
  If they are unavailable, the files automatically run an offline fallback
  instead of showing a traceback.
- Practical 13 uses the webcam when available. If the webcam is blocked or
  missing, it automatically processes the bundled sample image.
- Practical 14 uses real Tesseract OCR when the Tesseract desktop program is
  installed. If it is not installed, image preprocessing still completes and
  the script exits cleanly without an error.
- Practical 15 can be run directly with Python as an offline demo or through
  Streamlit for the camera interface. It does not require TensorFlow.

If you specifically want the FULL deep-learning versions of Practicals 10-12,
run this only when you have enough time and a good internet connection:

      OPTIONAL_DEEP_LEARNING_SETUP.bat

This is NOT required for TEST_ALL.bat or for the safe versions to run.

============================================================
PRACTICAL FILES
============================================================
01  Load, display and save images using OpenCV and Pillow
02  Histogram equalization on grayscale and color images
03  Gaussian and Median filtering
04  Sobel and Canny edge detection
05  Morphological transformations
06  Contour detection and analysis
07  Affine and perspective transformations
08  Haar cascade face detection
09  Template matching
10  YOLOv5 object detection + offline fallback
11  TensorFlow/Keras CNN for MNIST + offline neural-network fallback
12  ResNet50 flower fine-tuning + offline flower-classification fallback
13  Real-time webcam processing + sample-image fallback
14  Tesseract OCR + safe preprocessing fallback
15  Streamlit face-mask detector + offline demo

============================================================
QUICK CHECK
============================================================
The beginning of a normal terminal should show:

      (.venv)

To verify the interpreter:

      python -c "import sys; print(sys.executable)"

The result should end with:

      .venv\Scripts\python.exe

If VS Code opened an old terminal without (.venv), simply close that terminal
and choose Terminal -> New Terminal.
