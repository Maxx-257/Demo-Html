"""Practical 1: Load, display and save images using OpenCV and Pillow."""
from pathlib import Path
import os
import cv2
from PIL import Image
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
path = BASE / "assets" / "astronaut.jpg"
img_bgr = cv2.imread(str(path))
if img_bgr is None:
    print("Input image not found. Run from the supplied practical folder.")
    raise SystemExit(0)

cv2.imwrite(str(BASE / "output_opencv.jpg"), img_bgr)
Image.open(path).save(BASE / "output_pillow.png")

plt.imshow(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB))
plt.title("Loaded Image")
plt.axis("off")
plt.tight_layout()
plt.savefig(BASE / "output_display.png", dpi=120)
if os.environ.get("DIP_TEST_MODE") != "1":
    plt.show()
plt.close()
print("SUCCESS: image loaded with OpenCV/Pillow and outputs were saved.")
