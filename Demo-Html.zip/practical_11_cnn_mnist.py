"""Practical 11: CNN using TensorFlow/Keras for digit recognition.
The TensorFlow/Keras implementation is used when available. If TensorFlow or the
MNIST download is unavailable, a small offline NumPy digit-classification demo runs
instead so the practical does not terminate with an error.
"""
from pathlib import Path
import os, socket
import numpy as np

BASE = Path(__file__).resolve().parent

def internet_available():
    try:
        socket.create_connection(("storage.googleapis.com",443),timeout=2).close(); return True
    except OSError: return False

def offline_demo(reason):
    print("TensorFlow/MNIST full mode unavailable:", reason)
    print("Running safe offline NumPy neural-network digit demo...")
    # Seven-segment style 8x8 digit prototypes, then noisy samples.
    seg = {
      0:"ab cdef".replace(" ",""), 1:"bc", 2:"abdeg", 3:"abcdg",
      4:"bcfg", 5:"acdfg", 6:"acdefg", 7:"abc", 8:"abcdefg", 9:"abcdfg"
    }
    def draw(d):
        a=np.zeros((8,8),dtype=float)
        lines={"a":(1,1,1,6),"b":(1,6,3,6),"c":(4,6,6,6),"d":(6,1,6,6),"e":(4,1,6,1),"f":(1,1,3,1),"g":(3,1,3,6)}
        for s in seg[d]:
            y1,x1,y2,x2=lines[s]
            if y1==y2: a[y1, x1:x2+1]=1
            else: a[y1:y2+1, x1]=1
        return a
    rng=np.random.default_rng(42)
    X=[]; y=[]
    for d in range(10):
        p=draw(d)
        for _ in range(45):
            X.append(np.clip(p+rng.normal(0,0.18,p.shape),0,1).ravel()); y.append(d)
    X=np.array(X); y=np.array(y)
    idx=rng.permutation(len(X)); X=X[idx]; y=y[idx]
    cut=int(.8*len(X)); Xtr,Xte=X[:cut],X[cut:]; ytr,yte=y[:cut],y[cut:]
    # Simple two-layer NumPy neural network.
    W1=rng.normal(0,.15,(64,32)); b1=np.zeros(32); W2=rng.normal(0,.15,(32,10)); b2=np.zeros(10)
    Y=np.eye(10)[ytr]; lr=.25
    for _ in range(140):
        h=np.maximum(0,Xtr@W1+b1); z=h@W2+b2; z-=z.max(1,keepdims=True)
        p=np.exp(z); p/=p.sum(1,keepdims=True)
        dz=(p-Y)/len(Xtr); dW2=h.T@dz; db2=dz.sum(0); dh=dz@W2.T; dh[h<=0]=0
        dW1=Xtr.T@dh; db1=dh.sum(0)
        W2-=lr*dW2; b2-=lr*db2; W1-=lr*dW1; b1-=lr*db1
    pred=np.argmax(np.maximum(0,Xte@W1+b1)@W2+b2,axis=1)
    acc=(pred==yte).mean()
    print(f"Offline neural-network accuracy: {acc:.4f}")
    print("SUCCESS: digit-recognition fallback completed.")

if os.environ.get("DIP_FORCE_FALLBACK") == "1":
    offline_demo("fallback requested")
else:
    try:
        import tensorflow as tf
        from tensorflow.keras import Sequential
        from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Input
        # Use cached MNIST when present; otherwise require internet.
        cache = Path.home()/".keras"/"datasets"/"mnist.npz"
        if not cache.exists() and not internet_available():
            raise RuntimeError("MNIST is not cached and internet is unavailable")
        (x_train,y_train),(x_test,y_test)=tf.keras.datasets.mnist.load_data()
        x_train=(x_train[:12000].astype("float32")/255.0)[...,None]; y_train=y_train[:12000]
        x_test=(x_test[:2000].astype("float32")/255.0)[...,None]; y_test=y_test[:2000]
        model=Sequential([Input((28,28,1)),Conv2D(16,3,activation="relu"),MaxPooling2D(),Conv2D(32,3,activation="relu"),MaxPooling2D(),Flatten(),Dense(64,activation="relu"),Dense(10,activation="softmax")])
        model.compile(optimizer="adam",loss="sparse_categorical_crossentropy",metrics=["accuracy"])
        model.fit(x_train,y_train,epochs=2,batch_size=64,validation_split=.1,verbose=1)
        _,acc=model.evaluate(x_test,y_test,verbose=0)
        print(f"Test accuracy: {acc:.4f}")
        print("SUCCESS: TensorFlow/Keras CNN completed.")
    except Exception as e:
        offline_demo(f"{type(e).__name__}: {e}")
