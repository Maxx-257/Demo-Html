"""Practical 10: Object detection using pretrained YOLOv5.
If YOLOv5 cannot be downloaded/loaded, the file automatically runs an offline
OpenCV object-localization fallback instead of crashing.
"""
from pathlib import Path
import os, socket
import cv2

BASE = Path(__file__).resolve().parent
image_path = BASE / "assets" / "astronaut.jpg"

def internet_available():
    try:
        socket.create_connection(("github.com", 443), timeout=2).close()
        return True
    except OSError:
        return False

def offline_fallback(reason):
    print("YOLOv5 full mode unavailable:", reason)
    print("Running safe offline OpenCV object-localization fallback...")
    img = cv2.imread(str(image_path))
    if img is None:
        print("Input image not found.")
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = cascade.detectMultiScale(gray, 1.1, 5, minSize=(40,40)) if not cascade.empty() else []
    for x,y,w,h in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),3)
        cv2.putText(img,"person/face",(x,max(20,y-8)),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,0),2)
    cv2.imwrite(str(BASE / "output_object_detection_fallback.jpg"), img)
    print("Objects localized in fallback mode:", len(faces))
    print("SUCCESS: practical completed in offline fallback mode.")

if os.environ.get("DIP_FORCE_FALLBACK") == "1" or not internet_available():
    offline_fallback("internet unavailable or fallback requested")
else:
    try:
        import torch
        print("Loading pretrained YOLOv5s...")
        model = torch.hub.load("ultralytics/yolov5", "yolov5s", pretrained=True, trust_repo=True, verbose=False)
        results = model(str(image_path))
        try:
            table = results.pandas().xyxy[0][["name","confidence"]]
            print(table.to_string(index=False))
        except Exception:
            print("YOLOv5 inference completed.")
        results.save(save_dir=str(BASE / "yolov5_output"), exist_ok=True)
        print("SUCCESS: YOLOv5 output saved in yolov5_output.")
    except Exception as e:
        offline_fallback(f"{type(e).__name__}: {e}")
