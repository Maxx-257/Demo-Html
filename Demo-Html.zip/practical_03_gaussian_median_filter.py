"""Practical 3: Gaussian and Median filtering to denoise an image."""
from pathlib import Path
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
img = cv2.imread(str(BASE / "assets" / "astronaut.jpg"))
if img is None:
    print("Input image not found.")
    raise SystemExit(0)

noisy = img.copy()
rng = np.random.default_rng(42)
y = rng.integers(0, noisy.shape[0], 7000)
x = rng.integers(0, noisy.shape[1], 7000)
values = rng.choice([0, 255], 7000)
noisy[y, x] = np.column_stack([values, values, values])
gaussian = cv2.GaussianBlur(noisy, (5, 5), 0)
median = cv2.medianBlur(noisy, 5)
for name, arr in [("noisy", noisy), ("gaussian", gaussian), ("median", median)]:
    cv2.imwrite(str(BASE / f"output_{name}.jpg"), arr)

fig, ax = plt.subplots(1, 3, figsize=(11, 4))
for a, im, title in zip(ax, [noisy, gaussian, median], ["Noisy", "Gaussian", "Median"]):
    a.imshow(cv2.cvtColor(im, cv2.COLOR_BGR2RGB)); a.set_title(title); a.axis("off")
plt.tight_layout(); plt.savefig(BASE / "output_denoising_comparison.png", dpi=120)
if os.environ.get("DIP_TEST_MODE") != "1": plt.show()
plt.close(fig)
print("SUCCESS: Gaussian and Median denoising completed.")
