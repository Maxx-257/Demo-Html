"""Practical 7: Apply affine and perspective transformations."""
from pathlib import Path
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
img = cv2.imread(str(BASE / "assets" / "shapes.png"))
if img is None:
    print("Input image not found.")
    raise SystemExit(0)
h, w = img.shape[:2]
src_aff = np.float32([[50,50],[w-50,50],[50,h-50]])
dst_aff = np.float32([[80,90],[w-90,40],[110,h-40]])
affine = cv2.warpAffine(img, cv2.getAffineTransform(src_aff, dst_aff), (w,h))
src = np.float32([[40,40],[w-40,40],[40,h-40],[w-40,h-40]])
dst = np.float32([[100,20],[w-80,70],[40,h-30],[w-120,h-70]])
perspective = cv2.warpPerspective(img, cv2.getPerspectiveTransform(src,dst), (w,h))
cv2.imwrite(str(BASE / "output_affine.png"), affine)
cv2.imwrite(str(BASE / "output_perspective.png"), perspective)
fig, ax = plt.subplots(1,3,figsize=(11,4))
for a, im, title in zip(ax,[img,affine,perspective],["Original","Affine","Perspective"]):
    a.imshow(cv2.cvtColor(im,cv2.COLOR_BGR2RGB)); a.set_title(title); a.axis("off")
plt.tight_layout(); plt.savefig(BASE / "output_transformations.png", dpi=120)
if os.environ.get("DIP_TEST_MODE") != "1": plt.show()
plt.close(fig)
print("SUCCESS: affine and perspective transformations completed.")
