"""Practical 9: Template matching for object localization."""
from pathlib import Path
import os
import cv2
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
scene = cv2.imread(str(BASE / "assets" / "shapes.png"))
template = cv2.imread(str(BASE / "assets" / "template.png"))
if scene is None or template is None:
    print("Required sample assets were not found.")
    raise SystemExit(0)
result = cv2.matchTemplate(scene, template, cv2.TM_CCOEFF_NORMED)
_, max_val, _, max_loc = cv2.minMaxLoc(result)
th, tw = template.shape[:2]
out = scene.copy(); cv2.rectangle(out, max_loc, (max_loc[0]+tw,max_loc[1]+th), (0,0,0), 4)
cv2.imwrite(str(BASE / "output_template_match.png"), out)
print("Best match confidence:", round(float(max_val),4))
print("Best match top-left:", max_loc)
plt.imshow(cv2.cvtColor(out,cv2.COLOR_BGR2RGB)); plt.axis("off"); plt.title("Template Matching"); plt.tight_layout()
plt.savefig(BASE / "output_template_match_plot.png", dpi=120)
if os.environ.get("DIP_TEST_MODE") != "1": plt.show()
plt.close()
print("SUCCESS: template matching completed.")
