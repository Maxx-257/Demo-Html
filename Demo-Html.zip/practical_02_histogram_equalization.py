"""Practical 2: Histogram equalization on grayscale and color images."""
from pathlib import Path
import os
import cv2
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
img = cv2.imread(str(BASE / "assets" / "astronaut.jpg"))
if img is None:
    print("Input image not found.")
    raise SystemExit(0)

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
gray_eq = cv2.equalizeHist(gray)
ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
ycrcb[:, :, 0] = cv2.equalizeHist(ycrcb[:, :, 0])
color_eq = cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR)
cv2.imwrite(str(BASE / "output_gray_equalized.jpg"), gray_eq)
cv2.imwrite(str(BASE / "output_color_equalized.jpg"), color_eq)

fig, ax = plt.subplots(1, 3, figsize=(11, 4))
ax[0].imshow(gray, cmap="gray"); ax[0].set_title("Original Gray")
ax[1].imshow(gray_eq, cmap="gray"); ax[1].set_title("Equalized Gray")
ax[2].imshow(cv2.cvtColor(color_eq, cv2.COLOR_BGR2RGB)); ax[2].set_title("Equalized Color")
for a in ax: a.axis("off")
plt.tight_layout(); plt.savefig(BASE / "output_histogram_equalization.png", dpi=120)
if os.environ.get("DIP_TEST_MODE") != "1": plt.show()
plt.close(fig)
print("SUCCESS: grayscale and color histogram equalization completed.")
