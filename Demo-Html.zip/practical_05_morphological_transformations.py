"""Practical 5: Morphological transformations to segment images."""
from pathlib import Path
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
img = cv2.imread(str(BASE / "assets" / "shapes.png"), cv2.IMREAD_GRAYSCALE)
if img is None:
    print("Input image not found.")
    raise SystemExit(0)

_, binary = cv2.threshold(img, 180, 255, cv2.THRESH_BINARY_INV)
kernel = np.ones((5, 5), np.uint8)
results = {
    "binary": binary,
    "erosion": cv2.erode(binary, kernel, iterations=1),
    "dilation": cv2.dilate(binary, kernel, iterations=1),
    "opening": cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel),
    "closing": cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel),
}
for name, arr in results.items(): cv2.imwrite(str(BASE / f"output_{name}.png"), arr)
fig, ax = plt.subplots(1, 5, figsize=(14, 3))
for a, (name, arr) in zip(ax, results.items()):
    a.imshow(arr, cmap="gray"); a.set_title(name.title()); a.axis("off")
plt.tight_layout(); plt.savefig(BASE / "output_morphology.png", dpi=120)
if os.environ.get("DIP_TEST_MODE") != "1": plt.show()
plt.close(fig)
print("SUCCESS: erosion, dilation, opening and closing completed.")
