"""Regenerate the synthetic assets. The bundled astronaut.jpg is kept as supplied."""
from pathlib import Path
import cv2, numpy as np
from PIL import Image, ImageDraw, ImageFont
BASE=Path(__file__).resolve().parent; A=BASE/"assets"; A.mkdir(exist_ok=True)
scene=np.full((420,640,3),245,dtype=np.uint8)
cv2.rectangle(scene,(60,70),(220,220),(40,120,220),-1); cv2.circle(scene,(390,150),80,(60,190,80),-1)
cv2.rectangle(scene,(300,290),(510,370),(200,80,80),-1); cv2.putText(scene,"DIP",(70,330),cv2.FONT_HERSHEY_SIMPLEX,2.2,(20,20,20),5)
cv2.imwrite(str(A/"shapes.png"),scene); cv2.imwrite(str(A/"template.png"),scene[50:240,40:240])
canvas=Image.new("RGB",(900,240),"white"); d=ImageDraw.Draw(canvas)
try: font=ImageFont.truetype("arial.ttf",58)
except Exception: font=ImageFont.load_default()
d.text((40,70),"Digital Image Processing 2026",fill="black",font=font); canvas.save(A/"text_image.png")
print("Synthetic assets regenerated. astronaut.jpg remains unchanged.")
